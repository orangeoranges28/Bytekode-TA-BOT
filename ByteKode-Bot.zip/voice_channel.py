import discord

import helpers as h

last_channel_created = None
main_meeting_channel = None
breakout_category = None
breakout_text_category = None
breakout_rooms = []
breakout_text_channels = []

async def make_breakout_room(ctx, *, args):
  guild = ctx.guild

  global breakout_category
  global breakout_text_category
  if (not h.any_in_list(guild.categories, "Breakout rooms")):
    breakout_category = await guild.create_category("Breakout rooms")
    breakout_text_category = await guild.create_category("Breakout text channels")
    if (ctx.message.author.voice.channel != None):
      global main_meeting_channel
      main_meeting_channel = ctx.message.author.voice.channel
  else:
    breakout_category = discord.utils.get(guild.categories, name="Breakout rooms")
    breakout_text_category = discord.utils.get(guild.categories, name="Breakout text channels")
  
  voice_channels = breakout_category.voice_channels
  text_channels = breakout_text_category.text_channels

  global last_channel_created
  last_channel_created = await guild.create_voice_channel(args + " - {}".format(len(voice_channels) + 1), category=breakout_category)
  new_text_channel = await guild.create_text_channel(args + " - {}".format(len(voice_channels) + 1), category=breakout_text_category)

  global breakout_rooms
  breakout_rooms = voice_channels + [last_channel_created]
  global breakout_text_channels
  breakout_text_channels = text_channels + [new_text_channel]

  if (not h.person_in_channels(breakout_rooms, ctx.message.author.name) and ctx.message.author.voice.channel != None):
      main_meeting_channel = ctx.message.author.voice.channel


async def add_to_breakout_room(ctx, *args):
  if (len(args) == 0 or last_channel_created == None):
    return

  guild = ctx.guild
  members_not_connected = []

  for i in args[0]:
    member = await guild.fetch_member(int(i[3:21]))
    if (member.voice != None):
      await member.move_to(last_channel_created)
    else:
      members_not_connected.append(member.display_name)

  if (len(members_not_connected) != 0):
    await ctx.message.channel.send("The following users can't be moved until they connect to any voice channel: {}".format(members_not_connected))


async def return_to_main_meeting(ctx):
  message = ctx.message

  if ((h.person_in_channels(breakout_rooms, message.author.name) or message.author.voice.channel != None) and main_meeting_channel == None):
    await message.channel.send('Go to the main meeting then run ".return" again.')
    return;
  
  for i in breakout_rooms:
    for m in i.members:
      await m.move_to(main_meeting_channel if main_meeting_channel != None else message.author.voice.channel)
    await i.delete()
  
  for i in breakout_text_channels:
    await i.delete()
  
  await breakout_category.delete()
  await breakout_text_category.delete()

  breakout_rooms.clear()
  