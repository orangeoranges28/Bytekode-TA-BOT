from replit import db
import re
import datetime

guild_id = None

# gets the guild id
def init_assignments(guild):
  global guild_id
  guild_id = str(guild.id)
  
  if not guild_id in db.keys():
    db[guild_id] = {"assignments": []}

# gets a unique id for a date (older dates have smaller ids)
def get_date_id(d):
  return (d.year * 10000) + (d.month * 100) + (d.day)

# gets a date from a string formated mm/dd/yyyy
def string_to_date(date_string):
  split_date = date_string.split("/")
  return datetime.datetime(int(split_date[2]), int(split_date[0]), int(split_date[1]))

#changes a date into a nicer string
def format_date_string(date_string):
  d = string_to_date(date_string)

  new_string = ""

  new_string += d.strftime('%a') + ", "
  new_string += d.strftime('%b') + " "
  new_string += d.strftime('%d') + ", "
  new_string += d.strftime('%Y')

  return new_string

# adds assignment
async def add_assignment(ctx, args):
  init_assignments(ctx.message.guild)

  assignments = db[guild_id]["assignments"];

  name = ""
  assignment_date = ""
  for i in args:
    if (re.search("^\d{1,2}/\d{1,2}/\d{4}$", i)):
      assignment_date = i
    else:
      name += " " + i

  if (assignment_date == ""):
    await ctx.message.channel.send('Make sure to give the assignment a due date.\nExample: ".assign Math Homework 7/12/2021"')
    return
  elif (name == ""):
    await ctx.message.channel.send('Make sure to give the assignment a name.\nExample: ".assign Math Homework 7/12/2021"')
    return
  
  new_assignment = {"name": name, "date": assignment_date}
  db[guild_id]["assignments"] = list(assignments) + [new_assignment]

  await ctx.message.channel.send("Successfully assigned " + name)

  print(db[guild_id]["assignments"])

# gets assignments
async def get_assignments(ctx, show_old):
  print(ctx.message.guild)
  init_assignments(ctx.message.guild)

  assignments = list(db[guild_id]["assignments"])

  def sort_key(e):
    if (dict(e)["date"] != ''):
      d = string_to_date(dict(e)["date"])
      print(d.month)
      return get_date_id(d)
    else:
      return 0

  assignments.sort(key=sort_key)

  assignments_string = ""
  for i in assignments:
    date_dif = get_date_id(string_to_date(dict(i)["date"])) - get_date_id(datetime.datetime.now())
    if (date_dif >= -2 or show_old):
      dot_color = "green_square"

      if (date_dif < 1):
        dot_color = "diamonds"
      elif (date_dif == 1):
        dot_color = "red_square"
      elif (date_dif == 2):
        dot_color = "orange_square"
      elif (date_dif <= 4):
        dot_color = "yellow_square"

      assignments_string += f":{dot_color}:   {i['name']}:     {format_date_string(i['date']) if i['date'] != '' else 'No due date'}\n"

  await ctx.message.channel.send(assignments_string if assignments_string != "" else "No assignments")

# resets assignments (for debuging)
async def reset_assignments(ctx):
  init_assignments(ctx.message.guild)

  if guild_id in db.keys():
    db[guild_id]["assignments"] = []
    print("reset assignments")
    await ctx.message.channel.send("Successfully cleared assignments")
  else:
    print("no asignments")
    await ctx.message.channel.send("No assignments to clear")