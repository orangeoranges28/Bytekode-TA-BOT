import discord
import os
import random
import asyncio
from discord.ext import commands

import voice_channel
import assignments
from keep_alive import keep_alive

client = discord.Client()
client = commands.Bot(command_prefix = '.')

answering = False
qNum = 0
subject = ""
stop_asking = False
correct = True
counter = 0
oldQuestion = ""
question = ""
done = False
score = 0


socialStudiesQuestions = {'Who is current president of the United States?':
                         ('\na. Barack Obama\nb. Joe Biden\nc. John F. Kennedy\nd. Bill Clinton\n', 'b'),
                         'What is the capital of USA?':
                         ('\na. Seattle\nb. New York City\nc. Washington DC\nd. London', 'c'),
                         'When was the American Revolution':
                         ('\na. 1756-1761\nb. 1675-1683\nc. 1774-1788\nd. 1775-1783', 'd'),
                         'What was the main reason the pilgrims left England to found Plymouth Colony?':
                         ('\na. They wanted to convert the natives to Christianity.\nb. They wanted to worship God in their own way.\nc. They wanted to sail across the Atlantic to search for wealth.\nd. They wanted to be first to claim land in the New World.', 'b'),
                         '______ led an attack on Harper\'s Ferry, Virginia, in order to provoke a slave revolt? https://ibb.co/GFsY0Dw':
                         ('\na. Dred Scott\nb. John Brown\nc. Robert E. Lee\nd. Daniel Shays', 'b'),
                         'Who was the president who made the Louisiana Purchase?':
                         ('\na. George Washington\nb. Abraham Lincoln\nc. John Adams\nd. Thomas Jefferson', 'd'),
                         'Which body has the power to impeach the president?':
                         ('\na. the Senate\nb. the House of Representatives\nc. the Supreme Court\nd. the people by popular vote', 'b'),
                         'Who has the power to ratify or approve a treaty made by the president?':
                         ('\na. the Senate\nb. the House of Representatives\nc. the Supreme Court\nd. the Vice President', 'a'),
                         'Which type of map shows average weather and rain of a region?':
                         ('\na. physical map\nb. topograph map\nc. weatherical map\nd. climate map', 'd')
                         }
scienceQuestions = {'What is Newton\'s third law of motion?':
                   ('\na. Energy cannot be created or destroyed\nb. For every action there is opposite and \nc. Speedy things stay speedy\nd. Something in motion will remain in motion until acted on\n', 'b'),
                   'What is the direction of light changes when passing through glass?':
                   ('\na. Refraction\nb. Reflection\nc. Transparency\nd. Fluidity', 'a'),
                   'This type of bond involves the sharing of electron pairs between different atoms. What do you call this bond?':
                   ('\na. Mutuality\nb. Connection\nc. Covalent\nd. Concave', 'c'),
                   'What are the general stages of cellular respiration (in order)?':
                   ('\na. Glycolysis, Electron transport chain and Citric acid cycle\nb. prophase, prometaphase, metaphase, anaphase, and telophase\nc. telophase, prophase, anaphase, and metaphase.\nd. Glycolysis, Citric acid cycle and Electron transport chain', 'd'),
                   'What are the 4 nucleotides of DNA':
                   ('\na. D, N, A, C\nb. A, G, T, C\nc. A, C, U, G\nd. A, B, C, D', 'b'),
                   'What are the major steps of DNA replication?':
                   ('\na. Preparation, Priming, Copying, Termination\nb. RNA transcription, Identification, Replication \nc. Identification, Designation, Priming, Copying\nd. Allele acquiration, Replication, Deletion', 'a'),
                   'What is an protein composed of?':
                   ('\na. Nucleotides: A, G, T, C\nb. Different combinations of Fe, Re, and U\nc. Myocyte and Actin\nd. Amino acids', 'd'),
                   'What are the products of cellular respiration?':
                   ('\na. Water, glucose, carbon dioxide\nb. Protein, Nitrogen, ATP\nc. Water, ATP, oxygen\nd. Nothing is produced', 'c'),
                   'Why are bacteria becoming pan resistant?':
                   ('\na. The bacteria that survive antibiotic strikes are resistant and reproduce\nb. The development of biological warfare has released stronger traits into the ecosystem\nc. Humans have evolved to accept less antibiotics\nd. Our antibiotics have worn down since they were produced', 'a')
                   }

operatorList = ['*', '+', '/', '-']  

@client.event
async def on_ready():
  print("Bot is ready.")

@client.event
async def on_member_join(member):
  print(f"{member} has joined a server.")

@client.event
async def on_member_remove(member):
  print(f"{member} has left a server.")

@client.command()
async def clear(ctx, amount = 4):
  amount+=1
  await ctx.channel.purge(limit = amount)

@client.command(aliases=['pickarandomnumber'])
async def randomnumber(ctx, min = 0, max = 11):
  max+=1
  await ctx.send("Your random number is: "+str(random.randrange(min,max)))

@client.command(aliases=['flipacoin'])
async def coinflip(ctx):
  true = random.randrange(1,3)
  if true ==1:
    await ctx.send("It landed on heads!")
  else:
    await ctx.send("It landed on tails!")

@client.command()
async def commands(ctx):
  await ctx.send(('**".commands" for commands**'
  '\n \n**----Quiz Commands----**'
  '\n".quiz" for quizes'
  '\ntype "end quiz" to end the current quiz'
  '\n \n**----Random Commands----**'
  '\n".randomnumber {min} {max}" to generate a random number (Ex: __.randomnumber 10 34__, defaults to 0-10)'
  '\n".coinflip" to flip a coin '
  '\n".clear {amount}" to delete however many previous messages (Ex: __.clear 3__, defaults to 5)\n \n**----Breakout Rooms----**'
  '\n".breakout {name}" to create and breakout into breakout rooms (Ex: __.breakout Math Help__, defaults to the breakout room number)'
  '\n".add @users" to add them (Ex: __.add @John @Manny @Ellie__)'
  '\n.return to return to main channel\n \n**----Assignments----**'
  '\n".assign {name} {date}" to assign an assignment (Ex: __.assign Worksheet 1A 10/5/2021__, Date format is strictly MM/DD/YYYY)'
  '\n".allassignments" to get all your assignments'
  '\n".assignments" get the current assignments and the ones due up to three days ago'))

@client.command(name="quiz")
async def _questions(ctx):
  await ctx.send("How many questions would you like?")
  def check(msg):
    return msg.author == ctx.author and msg.channel == ctx.channel

  try:
    msg = await client.wait_for("message", timeout=120.0, check=check)

  except asyncio.TimeoutError:
    await ctx.send("Sorry, you didn't reply in time!")

  qNum = int(msg.content.lower())

  await ctx.send("Would you like quick maths, SS, science, or mixed questions?")
  def check(msg):
    return msg.author == ctx.author and msg.channel == ctx.channel and \
        msg.content.lower() in ["ss", "quick maths", "science", "mixed"]

  try:
    msg = await client.wait_for("message", timeout=120.0, check=check)

  except asyncio.TimeoutError:
    await ctx.send("Sorry, you didn't reply in time!")

  subject = msg.content.lower()
  await ctx.send("Chose "+subject+" questions.")

  for questions_number in range(qNum):
    while True:
      global done
      global stop_asking
      global counter
      if subject == "ss" and stop_asking == False:
        global question
        global oldQuestion
        global counter
        
        oldQuestion = question
        global correct
        if correct:
          counter = 0
          while oldQuestion == question:
            item = random.choice(list(socialStudiesQuestions.items()))
            question = item[0]
            (variants, answer) = item[1]
        
        stop_asking = False
        await ctx.send(question + variants + '\nPress \'a\', \'b\', \'c\' or \'d\' for your answer\n')

        def check(msg):
          return msg.author == ctx.author and msg.channel == ctx.channel

        try:
          msg = await client.wait_for("message", timeout=60.0, check=check)

        except asyncio.TimeoutError:
          if counter == 0:
              await ctx.send("You responded too slowly. Try again!")
          else:
              await ctx.send("You responded too slowly! Quiz ending from inactivity.")
          done = True
          if counter >= 1:
            await ctx.send("Quiz ended")
            stop_asking = True
            done = True
          counter+=1
          correct = False
          break
          

        attempt = msg.content.lower()

        if attempt not in {'a', 'b', 'c', 'd', 'end quiz'}:
            await ctx.send('Invalid input: only enter in a, b, c, or d for your response')
            correct = False

        elif attempt == answer:
            global score
            score+=1
            await ctx.send('Correct! You\'ve gotten '+str(score)+' questions right so far.')
            correct = True
            stop_asking = False
            break
        
        elif attempt == "end quiz":
            correct = True
            stop_asking = True
            break

        elif attempt!= answer and attempt != "end quiz" and done == False:
            await ctx.send('Incorrect!!! Try again.')
            correct = False

      elif subject == "science" and stop_asking == False:
        oldQuestion = question
        if correct:
          counter = 0
          while oldQuestion == question:
            item = random.choice(list(scienceQuestions.items()))
            question = item[0]
            (variants, answer) = item[1]
        
        stop_asking = False
        await ctx.send(question + variants + '\nPress \'a\', \'b\', \'c\' or \'d\' for your answer\n')

        def check(msg):
          return msg.author == ctx.author and msg.channel == ctx.channel

        try:
          msg = await client.wait_for("message", timeout=60.0, check=check)

        except asyncio.TimeoutError:
          if counter == 0:
                await ctx.send("You responded too slowly. Try again!")
          else:
                await ctx.send("You responded too slowly! Quiz ending from inactivity.")
          done = True
          if counter >= 1:
            await ctx.send("Quiz ended")
            stop_asking = True
            done = True
          counter+=1
          correct = False
          break
          

        attempt = msg.content.lower()

        if attempt not in {'a', 'b', 'c', 'd', 'end quiz'}:
            await ctx.send('Invalid input: only enter in a, b, c, or d for your response')
            correct = False

        elif attempt == answer:

            score+=1
            await ctx.send('Correct! You\'ve gotten '+str(score)+' questions right so far.')
            correct = True
            stop_asking = False
            break
        
        elif attempt == "end quiz":
            correct = True
            stop_asking = True
            break

        elif attempt!= answer and attempt != "end quiz" and done == False:
            await ctx.send('Incorrect!!! Try again.')
            correct = False

      elif subject == "quick maths" and stop_asking == False:
          oldQuestion = question
          
          if correct:
            counter = 0
            while oldQuestion == question:
              num1 = random.randrange(20)
              num2 = random.randrange(20)
              print(num1)
              print(num2)
             
              operator = random.choice(operatorList)
              print(operator)
              question = str(num1)+operator+str(num2)
              if operator == '*':
                answer = num1*(num2)
                print(answer)
              elif operator == '+':
                answer = num1+num2
                print(answer)
              elif operator == '-':
                answer = num1-num2
                print(answer)
              else:
                answer = num1/num2
                print(answer)
              
          
          stop_asking = False
          await ctx.send(question)

          def check(msg):
            return msg.author == ctx.author and msg.channel == ctx.channel

          try:
            msg = await client.wait_for("message", timeout=10.0, check=check)

          except asyncio.TimeoutError:
            if counter == 1 or counter == 0:
                await ctx.send("You responded too slowly. Try again!")
            elif counter == 2:
                await ctx.send("You responded too slowly! Quiz ending from inactivity.")
            
            if counter >= 2:
              await ctx.send("Quiz ended")
              stop_asking = True
              done = True
            
            counter+=1
            correct = False
            done = True
            break
          
          if msg.content.lower() == "end quiz":
              counter = 0
              await ctx.send("Quiz ended")
              correct = True
              stop_asking = True
              break
          
          try:
            attempt = int(msg.content.lower())

          except ValueError:
            await ctx.send('Invalid input: only enter numbers')
            correct = False
            break
        
          if attempt == answer:
              score+=1
              await ctx.send('Correct! You\'ve gotten '+str(score)+' questions right so far.')
              correct = True
              stop_asking = False
              break
          
          elif attempt == "end quiz":
              counter = 0
              correct = True
              stop_asking = True
              break

          elif attempt!= answer and attempt != "end quiz" and done == False:
              await ctx.send('Incorrect!!! Try again.')
              correct = False

      elif subject == "mixed" and stop_asking == False:
          oldQuestion = question
          if correct:
            while oldQuestion == question:
              chooser = random.randrange(1,4)
              if chooser == 1:
                counter = 0
                oldQuestion = question
                if correct:
                  while oldQuestion == question:
                    item = random.choice(list(socialStudiesQuestions.items()))
                    question = item[0]
                    (variants, answer) = item[1]
              
              elif chooser == 2:
                counter = 0
                oldQuestion = question
                if correct:
                  while oldQuestion == question:
                    item = random.choice(list(scienceQuestions.items()))
                    question = item[0]
                    (variants, answer) = item[1]
                
                
              elif chooser == 3:
                counter = 0
                num1 = random.randrange(20)
                num2 = random.randrange(20)
                print(num1)
                print(num2)
              
                operator = random.choice(operatorList)
                print(operator)
                question = str(num1)+operator+str(num2)
                if operator == '*':
                  answer = num1*(num2)
                  print(answer)
                elif operator == '+':
                  answer = num1+num2
                  print(answer)
                elif operator == '-':
                  answer = num1-num2
                  print(answer)
                else:
                  answer = num1/num2
                  print(answer)

          stop_asking = False

          if chooser == 3:
            await ctx.send(question)
          
          else:
            await ctx.send(question + variants + '\nPress \'a\', \'b\', \'c\' or \'d\' for your answer\n')  

        

          def check(msg):
            return msg.author == ctx.author and msg.channel == ctx.channel
          if chooser == 3:
            try:
              msg = await client.wait_for("message", timeout=10.0, check=check)

            except asyncio.TimeoutError:
              if counter == 1 or counter == 0:
                await ctx.send("You responded too slowly. Try again!")
              elif counter == 2:
                await ctx.send("You responded too slowly! Quiz ending from inactivity.")
              done = True
              if counter >= 2:
                await ctx.send("Quiz ended")
                stop_asking = True
                done = True
              counter+=1
              correct = False
              break

            if msg.content.lower() == "end quiz":
              counter = 0
              await ctx.send("Quiz ended")
              correct = True
              stop_asking = True
              break  

          else:
            try:
              msg = await client.wait_for("message", timeout=60.0, check=check)

            except asyncio.TimeoutError:
              if counter == 0:
                await ctx.send("You responded too slowly. Try again!")
              else:
                await ctx.send("You responded too slowly! Quiz ending from inactivity.")
              done = True
              if counter >= 1:
                await ctx.send("Quiz ended")
                stop_asking = True
                done = True
              counter+=1
              correct = False
              break
          
          attempt = msg.content.lower()

          if chooser == 3:
            try:
              attempt = int(msg.content.lower())

            except ValueError:
              await ctx.send('Invalid input: only enter numbers')
              correct = False
              break

          else:
            if attempt not in {'a', 'b', 'c', 'd', 'end quiz'}:
              await ctx.send('Invalid input: only enter in a, b, c, or d for your response')
              correct = False


          if attempt == answer:
              
              score+=1
              await ctx.send('Correct! You\'ve gotten '+str(score)+' questions right so far.')
              correct = True
              stop_asking = False
              break
          
          elif attempt == "end quiz":
              correct = True
              stop_asking = True
              break

          elif attempt!= answer and attempt != "end quiz" and done == False:
              await ctx.send('Incorrect!!! Try again.')
              correct = False
              break
        

    if stop_asking:

      await ctx.send("Quiz ended with a final score of "+str(score)+"!")
      answering = False
      qNum = 0
      subject = ""
      stop_asking = False
      correct = True
      counter = 0
      oldQuestion = ""
      question = ""
      done = False
      score = 0
      break

################   BREAKOUT ROOMS   #################  

# create breakout room
@client.command(name='breakout')
async def create_room(ctx, *, args = "Breakout Group"):
  await voice_channel.make_breakout_room(ctx, args=args)
  await ctx.message.channel.send('Add members to your breakout room using the ".add" command and @ing the people you want to add.')

# add person to breakout room
@client.command(name='add')
async def add_to_room(ctx, *args):
  await voice_channel.add_to_breakout_room(ctx, args)

# return people to main meeting
@client.command(name='return')
async def return_from_breakout_rooms(ctx, *args):
  await voice_channel.return_to_main_meeting(ctx)

################   ASSIGNMENTS   #################  

# assign an assingment
@client.command(name='assign')
async def add_assignment(ctx, *args):
  if (args != None):
    await assignments.add_assignment(ctx, args)
  else:
    await ctx.message.channel.send('Make sure to give the assignment a name and due date.\nExample: ".assign Math Homework 7/12/2021"')

# get assignments
@client.command(name='assignments')
async def get_assignments(ctx, args='none needed'):
  await assignments.get_assignments(ctx, False)

# get assignments
@client.command(name='allassignments')
async def get_all_assignments(ctx, args='none needed'):
  print("all assignments run")
  await assignments.get_assignments(ctx, True)

# reset assignments (for debuging)
@client.command(name='remove_all')
async def reset_assignments(ctx, args="none needed"):
  await assignments.reset_assignments(ctx)

keep_alive()
client.run(os.getenv('TOKEN'))
