def any_in_list(list, name):
  for i in iter(list):
    if (i.name == name):
      return True;
  return False;

def person_in_channels(channels, name):
  for i in channels:
    if (any_in_list(i.members, name)):
      return True
  return False;